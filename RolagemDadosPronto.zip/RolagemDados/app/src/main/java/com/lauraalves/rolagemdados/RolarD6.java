package com.lauraalves.rolagemdados;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class RolarD6 extends AppCompatActivity {

    private Button btnVoltar, btnRolar6;
    private ImageView imageResult;
    private TextView textResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_rolar_d6);

        btnVoltar = findViewById(R.id.btnVoltar);
        btnRolar6 = findViewById(R.id.btnRolar6);
        textResult = findViewById(R.id.textResult);
        imageResult = findViewById(R.id.imageResult);

        //Gerar numeros

        btnRolar6.setOnClickListener(view -> {
            Intent rolar6 = new Intent(getApplicationContext(), RolarD6.class);

            int numero = new Random().nextInt(5)+1;
            textResult.setText("Número: "+numero);

            Bundle dados = getIntent().getExtras();

            if(numero == 1){
                imageResult.setImageResource(R.drawable.d11);
            }
            else if (numero == 2){
                imageResult.setImageResource(R.drawable.d22);
            }

            else if (numero == 3){
                imageResult.setImageResource(R.drawable.d33);
            }
            else if (numero ==4){
                imageResult.setImageResource(R.drawable.d44);
            }
            else if (numero == 5){
                imageResult.setImageResource(R.drawable.d55);
            }
            else{
                imageResult.setImageResource(R.drawable.d66);
            }


            });

            //Voltar a tela principal

        btnVoltar.setOnClickListener(view -> {

        });


        btnVoltar.setOnClickListener(view1 -> {
            finish();
        });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    }