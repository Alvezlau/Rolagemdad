package com.lauraalves.rolagemdados;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class RolarD10 extends AppCompatActivity {

    private Button btnRolar10, btnVoltar1;
    private ImageView imageResult1;
    private TextView textResult1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_rolar_d10);

        btnRolar10 = findViewById(R.id.btnRolar10);
        btnVoltar1 = findViewById(R.id.btnVoltar1);
        textResult1 = findViewById(R.id.textResult1);
        imageResult1 = findViewById(R.id.imageResult1);

        //Gerar numeros

        btnRolar10.setOnClickListener(view -> {
            Intent rolar10 = new Intent(getApplicationContext(), RolarD10.class);

            int numero1 = new Random().nextInt(9)+1;
            textResult1.setText("Número: "+numero1);

            Bundle dados = getIntent().getExtras();

            if(numero1 == 1){
                imageResult1.setImageResource(R.drawable.d1);

            }
            else if (numero1 == 2){
                imageResult1.setImageResource(R.drawable.d2);
            }

            else if (numero1 == 3){
                imageResult1.setImageResource(R.drawable.d3);
            }
            else if (numero1 ==4){
                imageResult1.setImageResource(R.drawable.d4);
            }
            else if (numero1 == 5){
                imageResult1.setImageResource(R.drawable.d5);
            }
            else if (numero1 == 6){
                imageResult1.setImageResource(R.drawable.d6);
            }
            else if (numero1 == 7){
                imageResult1.setImageResource(R.drawable.d7);
            }
            else if (numero1 == 8){
                imageResult1.setImageResource(R.drawable.d8);
            }
            else if (numero1 == 9){
                imageResult1.setImageResource(R.drawable.d9);
            }
            else if (numero1 == 10){
                imageResult1.setImageResource(R.drawable.d10);
            }

        });

        //Voltar a tela principal

        btnVoltar1.setOnClickListener(view -> {

        });


        btnVoltar1.setOnClickListener(view1 -> {
            finish();
        });



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}