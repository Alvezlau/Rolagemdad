package com.lauraalves.rolagemdados;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private Button btnD6, btnD10, btnD20;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        btnD6 = findViewById(R.id.btnD6);
        btnD10 = findViewById(R.id.btnD10);
        btnD20 = findViewById(R.id.btnD20);

        btnD6.setOnClickListener(view -> {
            Intent rolar6 = new Intent(getApplicationContext(), RolarD6.class);

            startActivity(rolar6);
        });

        btnD10.setOnClickListener(view -> {
            Intent rolar10 = new Intent(getApplicationContext(), RolarD10.class);

            startActivity(rolar10);
        });

        btnD20.setOnClickListener(view -> {
            Intent rolar20 = new Intent(getApplicationContext(), RolarD20.class);

            startActivity(rolar20);
        });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}