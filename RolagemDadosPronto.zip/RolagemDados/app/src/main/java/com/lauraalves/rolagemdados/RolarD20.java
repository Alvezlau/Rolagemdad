package com.lauraalves.rolagemdados;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class RolarD20 extends AppCompatActivity {

    private Button btnRolar20, btnVoltar2;
    private ImageView imageResult2;
    private TextView textResult2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_rolar_d20);

        btnRolar20 = findViewById(R.id.btnRolar20);
        btnVoltar2 = findViewById(R.id.btnVoltar2);
        imageResult2 = findViewById(R.id.imageResult2);
        textResult2 = findViewById(R.id.textResult2);

        //Gerar numeros

        btnRolar20.setOnClickListener(view -> {
            Intent rolar20 = new Intent(getApplicationContext(), RolarD20.class);

            int numero2 = new Random().nextInt(19)+1;
            textResult2.setText("Número: "+numero2);

            Bundle dados = getIntent().getExtras();


            if(numero2 == 1){
                imageResult2.setImageResource(R.drawable.um);

            }
            else if (numero2 == 2){
                imageResult2.setImageResource(R.drawable.doi);
            }

            else if (numero2 == 3){
                imageResult2.setImageResource(R.drawable.tres);
            }
            else if (numero2 ==4){
                imageResult2.setImageResource(R.drawable.quatro);
            }
            else if (numero2 == 5){
                imageResult2.setImageResource(R.drawable.cinc);
            }
            else if (numero2 == 6){
                imageResult2.setImageResource(R.drawable.seis);
            }
            else if (numero2 == 7){
                imageResult2.setImageResource(R.drawable.ste);
            }
            else if (numero2 == 8){
                imageResult2.setImageResource(R.drawable.oito);
            }
            else if (numero2 == 9){
                imageResult2.setImageResource(R.drawable.nove);
            }
            else if (numero2 == 10){
                imageResult2.setImageResource(R.drawable.dez);
            }
            else if (numero2 == 11){
                imageResult2.setImageResource(R.drawable.onz);
            }
            else if (numero2 == 12){
                imageResult2.setImageResource(R.drawable.doz);
            }
            else if (numero2 == 13){
                imageResult2.setImageResource(R.drawable.trez);
            }
            else if (numero2 == 14){
                imageResult2.setImageResource(R.drawable.quat);
            }
            else if (numero2 == 15){
                imageResult2.setImageResource(R.drawable.quinz);
            }
            else if (numero2 == 16){
                imageResult2.setImageResource(R.drawable.deze);
            }
            else if (numero2 == 17){
                imageResult2.setImageResource(R.drawable.dezt);
            }
            else if (numero2 == 18){
                imageResult2.setImageResource(R.drawable.dezo);
            }
            else if (numero2 == 19){
                imageResult2.setImageResource(R.drawable.dezn);
            }
            else {
                imageResult2.setImageResource(R.drawable.vint);
            }
        });

        //Voltar a tela principal

        btnVoltar2.setOnClickListener(view -> {

        });


        btnVoltar2.setOnClickListener(view1 -> {
            finish();
        });



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}